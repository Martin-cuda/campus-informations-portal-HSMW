// ── FABIAN (ORIGINAL) ─────────────────────────────────────────────────────
// Raumfinder-Seite: zeigt Gebäude und Räume, erlaubt Belegungs-Toggle.
// Originalcode von Fabian, keine Logik-Änderungen.
//
// [MERGE: Claude] Styling-Anpassungen:
//   1. Wrapper <div style={{ padding: "2rem" }}> durch standard page-header-
//      Klassen ersetzt damit das Layout konsistent mit den anderen Seiten ist.
//   2. Haus-Buttons und Raum-Kacheln nutzen jetzt CSS-Variablen aus Fabian's
//      index.css (--accent, --card, --border, --radius, --green, --red) statt
//      hardcodierter Hex-Werte. Damit folgt die Seite dem gemeinsamen Theme.
//   3. Detail-Box nutzt .card-Klasse aus Fabian's index.css.
//   4. <h1> und <h2> durch .page-title / .page-subtitle ersetzt.
//   Fabian's gesamte JSX-Logik (useState, toggle, Formular) ist unverändert.
// ──────────────────────────────────────────────────────────────────────────

import { useState, useEffect } from "react";

// Gebäudedaten aus seperater Haueser Datei importieren (siehe src/data/haeuser.js)
import { initialHaeuser } from "../data/haeuser";

const API_URL = "http://localhost:8000"; // Backend-URL für Raumbelegungs-API

export default function Raumfinder() {
  // ── FABIAN: State (unverändert) ────────────────────────────────────────
  const [haeuser, setHaeuser]                     = useState(initialHaeuser);
  //haeuser = vollständige Liste aller Gebäude mit ihren Räumen (inkl. Belegungsstatus)
  const [ausgewaehltesHaus, setAusgewaehltesHaus] = useState(null);
  // ausgewaehltesHaus = aktuell angeklicktes Gebäude (null wenn keins ausgewählt)
  const [ausgewaehltesRaum, setAusgewaehltesRaum] = useState(null);
  // ausgewaehltesRaum = aktuell angeklickter Raum im Detailbereich (null wenn keins ausgewählt)
  const [formular, setFormular]                   = useState({ professor: "", modul: "", bis: "" });
  // formular = temporäre Eingabewerte für Professor, Modul und Belegungszeit im Detailbereich

// Beim Laden der Seite: aktuelle Belegungen vom Backend holen
useEffect(() => {
  fetch(`${API_URL}/api/raeume`)
    .then((r) => r.json())
    .then((data) => {
      const belegungen = data.belegungen || {};
      setHaeuser((prev) => prev.map((h) => ({
        ...h,
        raeume: h.raeume.map((r) => {
          const key = `${h.id}_${r.id}`;
          const belegung = belegungen[key];
          if (belegung) {
            return { ...r, belegt: true, professor: belegung.professor, modul: belegung.modul, bis: belegung.bis };
          }
          return { ...r, belegt: false, professor: "", modul: "", bis: "" };
        }),
      })));
    })
    .catch(() => console.warn("Backend nicht erreichbar – lokaler Modus"));
}, []);

  // ── FABIAN: Handler (unverändert) ─────────────────────────────────────
  // Haus-Button angeklickt: Zeige Räume dieses Hauses, setze Raum-Auswahl zurück
  const hausAnzeigen = (haus) => {
    setAusgewaehltesHaus(haus);
    setAusgewaehltesRaum(null);
  };

  // Klick auf einen Raum: Zeige Details dieses Raums im Formular, fülle Formular mit aktuellen Werten
  const raumAnzeigen = (raum) => {
    setAusgewaehltesRaum(raum);
    setFormular({ professor: raum.professor, modul: raum.modul, bis: raum.bis });
  };

  // BelegungsToggle: Wenn Raum belegt → markiere als frei, sonst → markiere als belegt mit Formular-Daten
  const raumToggle = async () => {
    if (ausgewaehltesRaum.belegt) {
      // Raum freigeben – DELETE Request ans Backend
      await fetch(`${API_URL}/api/raeume/belegen/${ausgewaehltesHaus.id}/${ausgewaehltesRaum.id}`, {
        method: "DELETE",
      });
    } else {
      // Raum belegen – POST Request ans Backend
      await fetch(`${API_URL}/api/raeume/belegen`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          haus_id: ausgewaehltesHaus.id,
          raum_id: ausgewaehltesRaum.id,
          professor: formular.professor,
          modul: formular.modul,
          bis: formular.bis,
        }),
      });
    }
    const neueHaeuser = haeuser.map((h) => {
      if (h.id !== ausgewaehltesHaus.id) return h;
      return {
        ...h,
        raeume: h.raeume.map((r) => {
          if (r.id !== ausgewaehltesRaum.id) return r;
          if (r.belegt) {
            return { ...r, belegt: false, professor: "", modul: "", bis: "" };
          } else {
            return { ...r, belegt: true, ...formular };
          }
        }),
      };
    });
    setHaeuser(neueHaeuser);
    const aktualisiertesHaus = neueHaeuser.find((h) => h.id === ausgewaehltesHaus.id);
    setAusgewaehltesHaus(aktualisiertesHaus);
    const aktualisiertesRaum = aktualisiertesHaus.raeume.find((r) => r.id === ausgewaehltesRaum.id);
    setAusgewaehltesRaum(aktualisiertesRaum);
  };

  return (
    <div>
      {/* [MERGE: Claude] page-header statt <h1> (konsistentes Layout) */}
      <div className="page-header fade-up">
        <div className="page-title">Raumfinder</div>
        <div className="page-subtitle">Gebäude & Belegungsstatus · HS Mittweida</div>
      </div>

      {/* ── FABIAN: Häuser-Auswahl ─────────────────────────────────────── */}
      {/* [MERGE: Claude] Inline-Farben durch CSS-Variablen ersetzt */}
      <div style={{ display: "flex", gap: "1rem", marginBottom: "1.5rem", flexWrap: "wrap" }} className="fade-up">
        {haeuser.map((haus) => (
          <button
            key={haus.id}
            onClick={() => hausAnzeigen(haus)}
            style={{
              padding: "10px 24px",
              fontSize: "14px",
              cursor: "pointer",
              backgroundColor: ausgewaehltesHaus?.id === haus.id ? "var(--accent)" : "var(--card)",
              color: ausgewaehltesHaus?.id === haus.id ? "#fff" : "#374151",
              border: "1px solid",
              borderColor: ausgewaehltesHaus?.id === haus.id ? "var(--accent)" : "var(--border)",
              borderRadius: "var(--radius)",
              fontFamily: "inherit",
              fontWeight: ausgewaehltesHaus?.id === haus.id ? 600 : 400,
              transition: "all 0.15s",
            }}
          >
            {haus.name}
          </button>
        ))}
      </div>

      {/* ── FABIAN: Räume des gewählten Hauses ───────────────────────── */}
      {ausgewaehltesHaus && (
        <div className="fade-up">
          {/* [MERGE: Claude] <h2> durch page-subtitle-Style ersetzt */}
          <div style={{ fontSize: 14, fontWeight: 600, color: "#64748b", marginBottom: 14, textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "IBM Plex Mono, monospace" }}>
            {ausgewaehltesHaus.name} – Räume
          </div>

          <div style={{ display: "flex", gap: "1rem", flexWrap: "wrap", marginBottom: "1.5rem" }}>
            {ausgewaehltesHaus.raeume.map((raum) => (
              <div
                key={raum.id}
                onClick={() => raumAnzeigen(raum)}
                style={{
                  padding: "1rem",
                  width: "150px",
                  textAlign: "center",
                  borderRadius: "var(--radius)",
                  cursor: "pointer",
                  // [MERGE: Claude] --green / --red statt hardcodiert
                  backgroundColor: raum.belegt ? "var(--red)" : "var(--green)",
                  color: "white",
                  fontWeight: "bold",
                  border: "3px solid",
                  borderColor: ausgewaehltesRaum?.id === raum.id ? "var(--navy)" : "transparent",
                  transition: "border-color 0.15s",
                }}
              >
                <div>{raum.name}</div>
                <div style={{ fontSize: "0.8rem", marginTop: 4, opacity: 0.85 }}>{raum.etage}</div>
                <div style={{ marginTop: 4 }}>{raum.belegt ? "Belegt" : "Frei"}</div>
              </div>
            ))}
          </div>

          {/* ── FABIAN: Raum-Detailbereich ────────────────────────── */}
          {/* [MERGE: Claude] <div style={{ background:"#f5f5f5"... }}> → .card-Klasse */}
          {ausgewaehltesRaum && (
            <div className="card" style={{ maxWidth: "420px" }}>
              <div style={{ fontSize: 16, fontWeight: 600, color: "#0f172a", marginBottom: 14 }}>
                {ausgewaehltesRaum.name}
              </div>

              {ausgewaehltesRaum.belegt ? (
                <div>
                  <p style={{ marginBottom: 6, fontSize: 14, color: "#374151" }}>
                    <strong>Professor:</strong> {ausgewaehltesRaum.professor}
                  </p>
                  <p style={{ marginBottom: 6, fontSize: 14, color: "#374151" }}>
                    <strong>Modul:</strong> {ausgewaehltesRaum.modul}
                  </p>
                  <p style={{ marginBottom: 12, fontSize: 14, color: "#374151" }}>
                    <strong>Belegt bis:</strong> {ausgewaehltesRaum.bis} Uhr
                  </p>
                  <button
                    onClick={raumToggle}
                    className="btn-primary"
                    style={{ background: "var(--green)", width: "auto", padding: "9px 20px" }}
                  >
                    Als frei markieren
                  </button>
                </div>
              ) : (
                <div>
                  <p style={{ marginBottom: 12, fontSize: 14, color: "#64748b" }}>
                    Dieser Raum ist aktuell frei.
                  </p>
                  <label className="login-label">Professor</label>
                  <input
                    className="login-input"
                    placeholder="z.B. Prof. Dr. Roschke"
                    value={formular.professor}
                    onChange={(e) => setFormular({ ...formular, professor: e.target.value })}
                  />
                  <label className="login-label">Modul</label>
                  <input
                    className="login-input"
                    placeholder="z.B. Informatik II"
                    value={formular.modul}
                    onChange={(e) => setFormular({ ...formular, modul: e.target.value })}
                  />
                  <label className="login-label">Belegt bis (z.B. 14:30)</label>
                  <input
                    className="login-input"
                    placeholder="14:30"
                    value={formular.bis}
                    onChange={(e) => setFormular({ ...formular, bis: e.target.value })}
                  />
                  <button
                    onClick={raumToggle}
                    className="btn-primary"
                    style={{ background: "var(--red)", width: "auto", padding: "9px 20px" }}
                  >
                    Als belegt markieren
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
